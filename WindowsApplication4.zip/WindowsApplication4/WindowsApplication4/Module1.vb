﻿Module Module1
    Public Brukernavn1 As String
    Public Passord1 As String

    Public EndrePassord As New frmEndrePassord
End Module

Module Module2
    Public Brukernavn2 As String
    Public Passord2 As String

    Public NyBruker As New frmNyBruker
End Module